<template>
  
  <div class="container-fluid">
    <div class="row">
      <div class="col-8">
        <div class="row">
          <div class="col-12">
            <h1>流程圖</h1>
          </div>
        </div>
        <div class="row">
          <img src="./assets/diagram.png" class="img-fluid" alt="Responsive image">
        </div>
        <div class="row">
          <div class="col-5">
            <div class="card bg-light mb-3">
              <div class="card-header">控制元件</div>
              <div class="card-body">
                <div class="row" >
                  <div class="col">
                    <button type="button" :class="'disabled btn btn-'+ (operator.heapControl[0]==0?'secondary':operator.heapControl[0]>0?'danger':'primary')">熱交換1</button>
                  </div>
                  <div class="col">
                    <button type="button" :class="'disabled btn btn-'+ (operator.heapControl[1]==0?'secondary':operator.heapControl[1]>0?'danger':'primary')">熱交換2</button>
                  </div>
                  <div class="col">
                    <button type="button" :class="'disabled btn btn-'+ (operator.heapControl[2]==0?'secondary':operator.heapControl[2]>0?'danger':'primary')">熱交換3</button>
                  </div>
                </div>
                <hr>
                <div class="row" >
                  <div class="col">
                    <button type="button" :class="'disabled btn btn-'+ (operator.pumb[0]==0?'secondary':operator.pumb[0]>0?'danger':'primary')">進料流量</button>
                  </div>
                  <div class="col">
                    <button type="button" :class="'disabled btn btn-'+ (operator.pumb[1]==0?'secondary':operator.pumb[1]>0?'danger':'primary')">廢水流量</button>
                  </div>
                  <div class="col">
                    <button type="button" :class="'disabled btn btn-'+ (operator.pumb[2]==0?'secondary':operator.pumb[2]>0?'danger':'primary')">淤泥流量</button>
                  </div>
                </div>
                <hr>
                <div class="row" >
                  <div class="col">
                    <button type="button" :class="'disabled btn btn-'+ (operator.pH[0]==0?'secondary':operator.pH[0]>0?'danger':'primary')">進料酸鹼1</button>
                  </div>
                  <div class="col">
                    <button type="button" :class="'disabled btn btn-'+ (operator.pH[1]==0?'secondary':operator.pH[1]>0?'danger':'primary')">廢水酸鹼2</button>
                  </div>
                  <div class="col">
                    <button type="button" :class="'disabled btn btn-'+ (operator.pH[2]==0?'secondary':operator.pH[2]>0?'danger':'primary')">淤泥酸鹼3</button>
                  </div>
                </div>
                <hr>
                <div class="row" >
                  <div class="col-6">
                    <button type="button" :class="'btn btn-'+ (pause==false?'success':'warning')" @click="pause=!pause">暫停模擬</button>
                  </div>
                  <div class="col-6">
                    <button type="button" class="btn btn-secondary" @click="init_outputWindow">控制紀錄</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-7">
            <div class="card bg-light mb-3">
              <div class="card-header">模擬操作</div>
              <div class="card-body">
                <div class="row" >
                  <div class="col">
                    <button type="button" class="btn  btn-block btn-danger" @click="()=>{sensor.thermometer.input_first+=2;}">提升溫度1</button>
                  </div>
                  <div class="col">
                    <button type="button" class="btn  btn-block btn-primary" @click="()=>{sensor.thermometer.input_first-=2;}">降低溫度1</button>
                  </div>
                  <div class="col">
                    <button type="button" class="btn  btn-block btn-danger" @click="()=>{sensor.thermometer.input_AAO+=2;}">提升溫度2</button>
                  </div>
                  <div class="col">
                    <button type="button" class="btn  btn-block btn-primary" @click="()=>{sensor.thermometer.input_AAO-=2;}">降低溫度2</button>
                  </div>
                  <div class="col">
                    <button type="button" class="btn  btn-block btn-danger" @click="()=>{sensor.thermometer.input_dirt+=2;}">提升溫度3</button>
                  </div>
                  <div class="col">
                    <button type="button" class="btn  btn-block btn-primary" @click="()=>{sensor.thermometer.input_dirt-=2;}">降低溫度3</button>
                  </div>
                </div>
                <hr>
                <div class="row" >
                  <div class="col">
                    <button type="button" class="btn btn-block btn-danger" @click="()=>{sensor.presuremeter.input_first+=1;}">提升壓力1</button>
                  </div>
                  <div class="col">
                    <button type="button" class="btn btn-block btn-primary" @click="()=>{sensor.presuremeter.input_first-=1;}">降低壓力1</button>
                  </div>
                  <div class="col">
                    <button type="button" class="btn btn-block btn-danger" @click="()=>{sensor.presuremeter.input_AAO+=1;}">提升壓力2</button>
                  </div>
                  <div class="col">
                    <button type="button" class="btn btn-block btn-primary" @click="()=>{sensor.presuremeter.input_AAO-=1;}">降低壓力2</button>
                  </div>
                  <div class="col">
                    <button type="button" class="btn btn-block btn-danger" @click="()=>{sensor.presuremeter.input_dirt+=1;}">提升壓力3</button>
                  </div>
                  <div class="col">
                    <button type="button" class="btn btn-block btn-primary" @click="()=>{sensor.presuremeter.input_dirt-=1;}">降低壓力3</button>
                  </div>
                </div>
                <hr>
                <div class="row" >
                  <div class="col">
                    <button type="button" class="btn btn-block btn-danger" @click="()=>{sensor.pHmeter.input_first+=1;}">提升鹼度1</button>
                  </div>
                  <div class="col">
                    <button type="button" class="btn btn-block btn-primary" @click="()=>{sensor.pHmeter.input_first-=1;}">降低鹼度1</button>
                  </div>
                  <div class="col">
                    <button type="button" class="btn btn-block btn-danger" @click="()=>{sensor.pHmeter.input_AAO+=1;}">提升鹼度2</button>
                  </div>
                  <div class="col">
                    <button type="button" class="btn btn-block btn-primary" @click="()=>{sensor.pHmeter.input_AAO-=1;}">降低鹼度2</button>
                  </div>
                  <div class="col">
                    <button type="button" class="btn btn-block btn-danger" @click="()=>{sensor.pHmeter.input_dirt+=1;}">提升鹼度3</button>
                  </div>
                  <div class="col">
                    <button type="button" class="btn btn-block btn-primary" @click="()=>{sensor.pHmeter.input_dirt-=1;}">降低鹼度3</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-4">
        <div>
          <h1>圖表記錄</h1>
        </div>
        <canvas id="myChart1"></canvas>
        <canvas id="myChart2"></canvas>
        <canvas id="myChart3"></canvas>
      </div>
    </div>
  </div>
</template>

<script>
import Chart from 'chart.js/auto';
import { shallowRef } from 'vue';

export default {
  name: 'App',
  data:()=>({
      operator:{
        heapControl:[0.0,0.0,0.0],
        pumb:[0.0,0.0,0.0],
        pH:[0.0,0.0,0.0],
        prev_heapControl:[0,0,0],
        prev_pumb:[0,0,0],
        prev_pH:[0,0,0],
      },
      sensor:{
        thermometer:{
          prev_first: 25,
          input_first: 25,
          prev_AAO: 35,
          input_AAO: 35,
          prev_dirt: 34,
          input_dirt: 34,
        },
        presuremeter:{
          input_first: 0.3,
          input_AAO: 1.1,
          input_dirt: 1.2,
          prev_first: 0.3,
          prev_AAO: 1.1,
          prev_dirt: 1.2,
        },
        pHmeter:{
          input_first: 7,
          input_AAO: 8.3,
          input_dirt: 7, 
          prev_first: 7,
          prev_AAO: 8.3,
          prev_dirt: 7, 
        },
        liqudlevelmeter:{
          input_AAO: 0.5,
          input_dirt: 0.6,
        },
      },
      tempChart: null,
      presureChart: null,
      pHChart: null,
      outputWindow: null,
      pause:false,
  }),
  mounted(){
    this.mountChart();
    setInterval(() => {
      if(!this.pause){
        this.updateChart();
      }
    }, 1500);
    setInterval(() => {
      if(!this.pause){
      this.startSm();
      }
    }, 1000);
    setInterval(() => {
      if(!this.pause){
      this.AIcontrol();
      }
    }, 1000);
  },
  methods:{
    init_outputWindow :function(){
      this.outputWindow = window.open("","outputWindow","width=400,height=400");
      this.log(`控制紀錄視窗初始化`);
    },
    log :function(msg){
      this.outputWindow.document.write(`${new Date().toLocaleTimeString()} - ${msg}<br>`);
    },
    AIcontrol :function(){
      if(this.sensor.thermometer.input_first > 26){
        this.operator.heapControl[0] = -((this.sensor.thermometer.input_first-26)*0.1);
      }else if(this.sensor.thermometer.input_first < 24){
        this.operator.heapControl[0] = -((this.sensor.thermometer.input_first-24)*0.1);
      }else{
        this.operator.heapControl[0] = 0;
      }
      if(this.sensor.thermometer.input_AAO > 40){
        this.operator.heapControl[1] = -((this.sensor.thermometer.input_AAO-40)*0.1);
      }else if(this.sensor.thermometer.input_AAO < 30){
        this.operator.heapControl[1] = -((this.sensor.thermometer.input_AAO-30)*0.1);
      }else{
        this.operator.heapControl[1] = 0;
      }
      if(this.sensor.thermometer.input_dirt > 35){
        this.operator.heapControl[2] = -((this.sensor.thermometer.input_dirt-35)*0.1);
      }else if(this.sensor.thermometer.input_dirt < 33.5){
        this.operator.heapControl[2] = -((this.sensor.thermometer.input_dirt-33.5)*0.1);
      }else{
        this.operator.heapControl[2] = 0;
      }

      this.sensor.thermometer.input_first += this.operator.heapControl[0];
      this.sensor.thermometer.input_AAO += this.operator.heapControl[1];
      this.sensor.thermometer.input_dirt += this.operator.heapControl[2];

      if(this.sensor.pHmeter.input_first > 7.5){
        this.operator.pH[0] = -((this.sensor.pHmeter.input_first-7.5)*0.1);
      }else if(this.sensor.pHmeter.input_first < 6.5){
        this.operator.pH[0] = -((this.sensor.pHmeter.input_first-6.5)*0.1);
      }else{
        this.operator.pH[0] = 0;
      }
      if(this.sensor.pHmeter.input_AAO > 8.6){
        this.operator.pH[1] = -((this.sensor.pHmeter.input_AAO-8.6)*0.1);
      }else if(this.sensor.pHmeter.input_AAO < 8){
        this.operator.pH[1] = -((this.sensor.pHmeter.input_AAO-8)*0.1);
      }else{
        this.operator.pH[1] = 0;
      }
      if(this.sensor.pHmeter.input_dirt > 7.8){
        this.operator.pH[2] = -((this.sensor.pHmeter.input_dirt-7.8)*0.1);
      }else if(this.sensor.pHmeter.input_dirt < 6.5){
        this.operator.pH[2] = -((this.sensor.pHmeter.input_dirt-6.5)*0.1);
      }else{
        this.operator.pH[2] = 0;
      }

      this.sensor.pHmeter.input_first += this.operator.pH[0];
      this.sensor.pHmeter.input_AAO += this.operator.pH[1];
      this.sensor.pHmeter.input_dirt += this.operator.pH[2];

      if(this.sensor.presuremeter.input_first > 0.493462){
        this.operator.pumb[0] = -((this.sensor.presuremeter.input_first-0.493462)*0.1);
      }else if(this.sensor.presuremeter.input_first < 0.1){
        this.operator.pumb[0] = -((this.sensor.presuremeter.input_first-0.1)*0.1);
      }else{
        this.operator.pumb[0] = 0;
      }
      if(this.sensor.presuremeter.input_AAO > 1.5){
        this.operator.pumb[1] = -((this.sensor.presuremeter.input_AAO-1.5)*0.1);
      }else if(this.sensor.presuremeter.input_AAO < 1){
        this.operator.pumb[1] = -((this.sensor.presuremeter.input_AAO-1)*0.1);
      }else{
        this.operator.pumb[1] = 0;
      }
      if(this.sensor.presuremeter.input_dirt > 1.5){
        this.operator.pumb[2] = -((this.sensor.presuremeter.input_dirt-1.5)*0.1);
      }else if(this.sensor.presuremeter.input_dirt < 1){
        this.operator.pumb[2] = -((this.sensor.presuremeter.input_dirt-1)*0.1);
      }else{
        this.operator.pumb[2] = 0;
      }

      this.sensor.presuremeter.input_first += this.operator.pumb[0];
      this.sensor.presuremeter.input_AAO += this.operator.pumb[1];
      this.sensor.presuremeter.input_dirt += this.operator.pumb[2];

      for(let i in this.operator.heapControl){
        if(this.operator.heapControl[i] > 0 && this.operator.prev_heapControl[i] != 1){
          this.operator.prev_heapControl[i] = 1;
          this.log(`溫度感測器${Number(i)+1}溫度過低，熱交換器${Number(i)+1}進行升溫`);
        }else if(this.operator.heapControl[i] < 0 && this.operator.prev_heapControl[i] != -1){
          this.operator.prev_heapControl[i] = -1;
          this.log(`溫度感測器${Number(i)+1}溫度過高，熱交換器${Number(i)+1}進行降溫`);
        }else if(this.operator.heapControl[i] == 0 && this.operator.prev_heapControl[i] != 0){
          this.operator.prev_heapControl[i] = 0;
          this.log(`溫度感測器${Number(i)+1}溫度正常，熱交換器${Number(i)+1}維持恆溫`);
        }
      }
      for(let i in this.operator.pH){
        if(this.operator.pH[i] > 0 && this.operator.prev_pH[i] != 1){
          this.operator.prev_pH[i] = 1;
          this.log(`酸鹼感測器${Number(i)+1}pH過低，酸鹼控制器${Number(i)+1}加入鹼`);
        }else if(this.operator.pH[i] < 0 && this.operator.prev_pH[i] != -1){
          this.operator.prev_pH[i] = -1;
          this.log(`酸鹼感測器${Number(i)+1}pH過高，酸鹼控制器${Number(i)+1}加入酸`);
        }else if(this.operator.pH[i] == 0 && this.operator.prev_pH[i] != 0){
          this.operator.prev_pH[i] = 0;
          this.log(`酸鹼感測器${Number(i)+1}pH正常，酸鹼控制器${Number(i)+1}維持恆定`);
        }
      }
      for(let i in this.operator.pumb){
        if(this.operator.pumb[i] > 0 && this.operator.prev_pumb[i] != 1){
          this.operator.prev_pumb[i] = 1;
          this.log(`壓力感測器${Number(i)+1}壓力過低，啟動幫浦${Number(i)+1}進行加壓`);
        }else if(this.operator.pumb[i] < 0 && this.operator.prev_pumb[i] != -1){
          this.operator.prev_pumb[i] = -1;
          this.log(`壓力感測器${Number(i)+1}壓力過高，啟動洩流閥${Number(i)+1}進行減壓`);
        }else if(this.operator.pumb[i] == 0 && this.operator.prev_pumb[i] != 0){
          this.operator.prev_pumb[i] = 0;
          this.log(`壓力感測器${Number(i)+1}壓力正常，壓力控制${Number(i)+1}維持恆定`);
        }
      }
    },
    startSm :function(){
      let randomFactor = (0.5-Math.random())*0.2;
      this.sensor.thermometer.input_first += randomFactor;
      this.sensor.thermometer.input_AAO += (this.sensor.thermometer.input_first-this.sensor.thermometer.prev_first)*0.9;
      this.sensor.thermometer.input_dirt += (this.sensor.thermometer.input_first-this.sensor.thermometer.prev_first)*0.9;
      this.sensor.thermometer.prev_first = this.sensor.thermometer.input_first;
      this.sensor.thermometer.prev_AAO = this.sensor.thermometer.input_AAO;
      this.sensor.thermometer.prev_dirt = this.sensor.thermometer.input_dirt;
      randomFactor = (0.5-Math.random())*0.2*0.3;
      this.sensor.pHmeter.input_first += randomFactor;
      this.sensor.pHmeter.input_AAO += (this.sensor.pHmeter.input_first-this.sensor.pHmeter.prev_first)*0.9;
      this.sensor.pHmeter.input_dirt += (this.sensor.pHmeter.input_first-this.sensor.pHmeter.prev_first)*0.9;
      this.sensor.pHmeter.prev_first = this.sensor.pHmeter.input_first;
      this.sensor.pHmeter.prev_AAO = this.sensor.pHmeter.input_AAO;
      this.sensor.pHmeter.prev_dirt = this.sensor.pHmeter.input_dirt;
      randomFactor = (0.5-Math.random())*0.2*0.1;
      this.sensor.presuremeter.input_first += randomFactor;
      this.sensor.presuremeter.input_AAO += (this.sensor.presuremeter.input_first-this.sensor.presuremeter.prev_first)*0.9;
      this.sensor.presuremeter.input_dirt += (this.sensor.presuremeter.input_first-this.sensor.presuremeter.prev_first)*0.9;
      this.sensor.presuremeter.prev_first = this.sensor.presuremeter.input_first;
      this.sensor.presuremeter.prev_AAO = this.sensor.presuremeter.input_AAO;
      this.sensor.presuremeter.prev_dirt = this.sensor.presuremeter.input_dirt;
    },
    updateChart(){
      let chart1 = this.tempChart.data;
      chart1.labels.push(new Date().toLocaleTimeString());
      chart1.datasets[0].data.push(this.sensor.thermometer.input_first);
      chart1.datasets[1].data.push(this.sensor.thermometer.input_AAO);   
      chart1.datasets[2].data.push(this.sensor.thermometer.input_dirt);   
      this.tempChart.update();

      let chart2 = this.presureChart.data;
      chart2.labels.push(new Date().toLocaleTimeString());
      chart2.datasets[0].data.push(this.sensor.presuremeter.input_first);
      chart2.datasets[1].data.push(this.sensor.presuremeter.input_AAO);   
      chart2.datasets[2].data.push(this.sensor.presuremeter.input_dirt);    
      this.presureChart.update();

      let chart3 = this.pHChart.data;
      chart3.labels.push(new Date().toLocaleTimeString());
      chart3.datasets[0].data.push(this.sensor.pHmeter.input_first);
      chart3.datasets[1].data.push(this.sensor.pHmeter.input_AAO);   
      chart3.datasets[2].data.push(this.sensor.pHmeter.input_dirt);    
      this.pHChart.update();

      if(chart1.labels.length > 10){
        chart1.labels.shift();
        chart1.datasets[0].data.shift();
        chart1.datasets[1].data.shift();
        chart1.datasets[2].data.shift();
      }

      if(chart2.labels.length > 10){
        chart2.labels.shift();
        chart2.datasets[0].data.shift();
        chart2.datasets[1].data.shift();
        chart2.datasets[2].data.shift();
      }

      if(chart3.labels.length > 10){
        chart3.labels.shift();
        chart3.datasets[0].data.shift();
        chart3.datasets[1].data.shift();
        chart3.datasets[2].data.shift();
      }

    },
    mountChart(){
      const ctx = document.getElementById('myChart1');
      this.tempChart = shallowRef(new Chart(ctx, {
        type: 'line',
        data: {
          labels: ["-", "-", "-", "-", "-", "-", "-", "-", "-", "-"],
          datasets: [
            {
              label: '初級處理反應槽',
              data: [15, 15, 15, 15, 15, 15, 15, 15, 15, 15],
              fill: false,
              borderColor: 'rgb(75, 192, 100)',
              tension: 0
            },
            {
              label: '廢水處理單元',
              data: [15, 15, 15, 15, 15, 15, 15, 15, 15, 15],
              fill: false,
              borderColor: 'rgb(205, 192, 192)',
              tension: 0
            },
            {
              label: '淤泥處理單元',
              data: [15, 15, 15, 15, 15, 15, 15, 15, 15, 15],
              fill: false,
              borderColor: 'rgb(100, 192, 192)',
              tension: 0
            }
          ]
        },
        options:{
          scales: {
            y: {
              min: 15,
              max: 70,
            }
          },
          plugins: {
              title: {
                  display: true,
                  text: 'Temperature'
              }
          }
        }
      }));
      const ctx2 = document.getElementById('myChart2');
      this.presureChart = shallowRef(new Chart(ctx2, {
        type: 'line',
        data: {
          labels: ["-", "-", "-", "-", "-", "-", "-", "-", "-", "-"],
          datasets: [
          {
              label: '初級處理反應槽',
              data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
              fill: false,
              borderColor: 'rgb(75, 192, 100)',
              tension: 0
            },
            {
              label: '廢水處理單元',
              data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
              fill: false,
              borderColor: 'rgb(205, 192, 192)',
              tension: 0
            },
            {
              label: '淤泥處理單元',
              data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
              fill: false,
              borderColor: 'rgb(100, 192, 192)',
              tension: 0
            }
          ]
        },
        options:{
          scales: {
            y: {
              min: 0,
              max: 2,
            }
          },
          plugins: {
              title: {
                  display: true,
                  text: 'Pressure'
              }
          }
        }
      }));
      const ctx3 = document.getElementById('myChart3');
      this.pHChart = shallowRef(new Chart(ctx3, {
        type: 'line',
        data: {
          labels: ["-", "-", "-", "-", "-", "-", "-", "-", "-", "-"],
          datasets: [
          {
              label: '初級處理反應槽',
              data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
              fill: false,
              borderColor: 'rgb(75, 192, 100)',
              tension: 0
            },
            {
              label: '廢水處理單元',
              data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
              fill: false,
              borderColor: 'rgb(205, 192, 192)',
              tension: 0
            },
            {
              label: '淤泥處理單元',
              data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
              fill: false,
              borderColor: 'rgb(100, 192, 192)',
              tension: 0
            }
          ]
        },
        options:{
          scales: {
            y: {
              min: 4,
              max: 12,
            }
          },
          plugins: {
              title: {
                  display: true,
                  text: 'pH'
              }
          }
        }
      }));
    },

  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 0px;
}

.navbar-custom {
  background-color: #d9ecff;

}
</style>
